<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>Access Denied</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<base href="<?php echo base_url();?>" />
<meta HTTP-EQUIV="REFRESH" content="5; url=<?php echo base_url();?>">
</head>
<body>
<div id="center" style="text-align:center;">
    <img src="assets/images/access_denied.png" />
	<h1>Access Denied</h1>
	<h2>Anda Tidak Diperbolehkan Mengakses Halaman ini...<a href="<?php echo base_url();?>">Kembali</a></h2>
</div>
</body>
</html>