<?php
/*
 * Aplikasi AKSIOMA (Aplikasi Keuangan Mikro Masyarakat Ekonomi Syariah) ver. 1.0
 * Copyright (c) 2014
 *
 * file   : header.php
 * author : Edi Suwoto S.Komp
 * email  : edi.suwoto@gmail.com
 */
/*----------------------------------------------------------*/
?>
<base href="<?php echo base_url();?>" />
<link type="text/css" href="assets/css/themes/<?php echo $tema?>/jquery-ui-1.7.css" rel="stylesheet" />
<!--<script type="text/javascript" src="assets/js/jq/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="assets/js/jq/jquery-ui-1.7.2.custom.min.js"></script>-->
<script type="text/javascript" src="assets/js/jq/jquery.masterTable.js"></script>
<script type="text/javascript" src="assets/js/jq/jquery.maskedinput.js" ></script>
<script type="text/javascript" src="assets/js/jq/jquery.inputValue.js"></script>
<script type="text/javascript" src="assets/js/fungsi.js"></script>
<script type="text/javascript" src="assets/js/jq/ui.datepicker-id.js"></script>

