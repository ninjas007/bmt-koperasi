<?php
/*
 * Aplikasi AKSIOMA (Aplikasi Keuangan Mikro Masyarakat Ekonomi Syariah) ver. 1.0
 * Copyright (c) 2014
 *
 * file   : spreadsheet_view.php
 * author : Edi Suwoto S.Komp
 * email  : edi.suwoto@gmail.com
 */
/*----------------------------------------------------------*/
?>
<?php
//header("Content-type: application/octet-stream");
//header("Content-Disposition: attachment; filename=$filename.xls");
//header("Pragma: no-cache");
//header("Expires: 0");
?>
<table border='1'>
  
</table>